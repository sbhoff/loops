package loops;

import java.util.ArrayList;

public class Loops2 {
	
	private Loops2() {
		
	}
	
	//return months taken to pay off intrest, cut off at 1,000,000
	public static int intrestYears(int n, double rate, int amount) {
		int months = 0;
		if(n*rate>= amount) {
			return -1;
		}
		
		while(n>0) {
			n = (int) Math.floor(n*rate);
			n = n- amount;
			months++;
		}
		return months;
	}
	
	//return a arraylist of all numberes in n who's last two digets are prime
	public static ArrayList<Integer> lastTwoIsPrime (String[] n) {
		ArrayList<Integer> prime = new ArrayList<Integer>();
		for(int i = 0; i < n.length; i++) {
			int a = Integer.parseInt(n[i].substring(n[i].length()-1));
			if(checkForPrime(a)) {
				prime.add(Integer.parseInt(n[i]));
			}
		}
		return prime;
	}
	
	static boolean checkForPrime(int inputNumber)
	{
	boolean isItPrime = true;
	 
	if(inputNumber <= 1) 
	{
	isItPrime = false;
	 
	return isItPrime;
	}
	else
	{
	for (int i = 2; i<= inputNumber/2; i++) 
	{
	if ((inputNumber % i) == 0)
	{
	isItPrime = false;
	 
	break;
	}
	}
	 
	return isItPrime;
	}
	}
	
	
	//repeate every number for how many the number is
	public void numberNumber (String n) {
		int i = 0;
		while (i<n.length()) {
			int a = Integer.parseInt( n.substring(i, i));
			boolean repeated = true;
			for(int b = 1; a<b; b++) {
				if(n.charAt(i)!=n.charAt(i-b)) {
					repeated = false;
				}
			}
			if(!repeated) {
				n = n.substring(0, i) + n.substring(i, n.length());
			}
			i++;
		}
	}

}

