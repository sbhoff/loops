package loops;

import java.util.ArrayList;

public class Loops {
	
	private Loops() {
		
	}
	
	//return months taken to pay off intrest, cut off at 1,000,000
	public static int intrestYears(int n, int rate, int amount) {
		int m = 0;
		while(n>=0 || m>100000){
			n = n * rate/100;
			n = n - amount;
			m++;
		}
		return m;
	}
	
	//return a arraylist of all numberes in n who's last two digets are prime
	public static ArrayList<Integer> lastTwoIsPrime (String[] n) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		for(int i = 0; i <= n.length; i++) {
			int a = Integer.parseInt(n[i].substring(n[i].length()-1));
			if(checkForPrime(a)) {
				primes.add(Integer.parseInt(n[i]));
			}
		}
		return primes;
	}
	
	static boolean checkForPrime(int inputNumber)
	{
	boolean isItPrime = true;
	 
	if(inputNumber <= 1) 
	{
	isItPrime = false;
	 
	return isItPrime;
	}
	else
	{
	for (int i = 2; i<= inputNumber/2; i++) 
	{
	if ((inputNumber % i) == 0)
	{
	isItPrime = false;
	 
	break;
	}
	}
	 
	return isItPrime;
	}
	}
	
	
	//repeate every number for how many the number is
	public void numberNumber (String n) {
		
	}

}
