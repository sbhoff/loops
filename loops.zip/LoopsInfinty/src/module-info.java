module loopsInfinty {
}